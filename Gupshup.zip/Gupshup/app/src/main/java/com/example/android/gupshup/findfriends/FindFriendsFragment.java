package com.example.android.gupshup.findfriends;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.gupshup.Common.Constants;
import com.example.android.gupshup.Common.NodeData;
import com.example.android.gupshup.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class FindFriendsFragment extends Fragment {

    private TextView tvEmptyFriendList;
    private RecyclerView rvFindFriends;
    private FindFriendAdapter findFriendAdapter;
    private List<FindFriendModel> findFriendModelList;
    private DatabaseReference databaseReference;
    private DatabaseReference friendRequestDatabase;

    private FirebaseUser firebaseUser;
    private View progressBar;


    public FindFriendsFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_find_friends, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvFindFriends = view.findViewById(R.id.rvFindFriends);
        tvEmptyFriendList = view.findViewById(R.id.tvEmptyFriendsList);
        progressBar = view.findViewById(R.id.progressBar);
        rvFindFriends.setLayoutManager(new LinearLayoutManager(getActivity()));
        findFriendModelList = new ArrayList<>();
        findFriendAdapter = new FindFriendAdapter(getActivity(),findFriendModelList);
        rvFindFriends.setAdapter(findFriendAdapter);
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        friendRequestDatabase = FirebaseDatabase.getInstance().getReference().child(NodeData.FRIEND_REQUESTS).child(firebaseUser.getUid());

        tvEmptyFriendList.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);

        Query query = databaseReference.orderByChild(NodeData.NAME);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                findFriendModelList.clear();
                for(DataSnapshot ds : snapshot.getChildren()){
                    String userId = ds.getKey();
                    if(userId.equals(firebaseUser.getUid()))
                        return;
                    if(ds.child(NodeData.NAME).getValue()!=null){
                        String name = ds.child(NodeData.NAME).getValue().toString();


                         String photoName = ds.child(NodeData.PHOTO).getValue().toString();
                        friendRequestDatabase.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists()){
                                   String requestType = snapshot.child(NodeData.REQUEST_TYPE).getValue().toString();
                                   if(requestType.equals(Constants.REQUEST_VALUE_SENT))

                                {findFriendModelList.add(new FindFriendModel(name,photoName,userId,true));
                                    findFriendAdapter.notifyDataSetChanged();

                                }}
                                else{
                                    findFriendModelList.add(new FindFriendModel(name,photoName,userId,false));
                                    findFriendAdapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                               progressBar.setVisibility(View.GONE);
                            }
                        });

                        tvEmptyFriendList.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), getContext().getString( R.string.failed_to_fetch_friends,error.getMessage())
                        , Toast.LENGTH_SHORT).show();


            }
        });
    }
}