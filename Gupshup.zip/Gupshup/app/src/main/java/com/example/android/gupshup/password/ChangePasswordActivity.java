package com.example.android.gupshup.password;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.android.gupshup.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {
    private TextInputEditText etNewPassword, etConfirmPassword;
    private String newPass,confirmPass;
    private View progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        progressBar = findViewById(R.id.custom_progressbar);
    }

    public void saveNewPassword(View view) {
       newPass = etNewPassword.getText().toString().trim();
       confirmPass = etConfirmPassword.getText().toString().trim();
        if(newPass.equals(""))
            etNewPassword.setError("Enter Password");
        else if(confirmPass.equals(""))
            etConfirmPassword.setError("Enter Password");
        else if(!newPass.equals(confirmPass))
            etConfirmPassword.setError("Enter correct password");
        else{
            progressBar.setVisibility(View.VISIBLE);
            FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
            FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
            if(firebaseUser!=null){
                firebaseUser.updatePassword(confirmPass).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressBar.setVisibility(View.GONE);
                        if(task.isSuccessful())
                        {
                        Toast.makeText(ChangePasswordActivity.this,R.string.password_changed_successfully,Toast.LENGTH_SHORT).show();

                            }
                        else
                            Toast.makeText(ChangePasswordActivity.this,getString(R.string.something_went_wrong,task.getException()),Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
}