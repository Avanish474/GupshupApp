package com.example.android.gupshup.Common;

public class Constants {
    public static  final  String IMAGES_FOLDER ="images";

    public static final Object REQUEST_VALUE_SENT = "sent";
    public static final Object REQUEST_VALUE_RECIEVED = "recieved";
    public static final Object REQUEST_STATUS_ACCEPTED = "accepted";
    public static final String MESSAGE_TYPE_TEXT ="text" ;
}
